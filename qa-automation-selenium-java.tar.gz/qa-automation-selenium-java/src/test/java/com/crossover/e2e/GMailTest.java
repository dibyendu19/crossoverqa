package com.crossover.e2e;

import java.io.File;
import java.io.FileReader;
import java.util.Properties;
import junit.framework.TestCase;
import org.junit.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import java.util.concurrent.TimeUnit;


public class GMailTest extends TestCase {
    private WebDriver driver;
    private Properties properties = new Properties();

    public void setUp() throws Exception {
        
        properties.load(new FileReader(new File("src/test/resources/test.properties")));
        //Dont Change below line. Set this value in test.properties file incase you need to change it..
        System.setProperty("webdriver.chrome.driver",properties.getProperty("webdriver.chrome.driver") );
        driver = new ChromeDriver();
    }

    public void tearDown() throws Exception {
        driver.quit();
    }

    /*
     * Please focus on completing the task
     * 
     */
    
    @Test
    public void testSendEmail() throws Exception {
        driver.get("https://mail.google.com/");
       
        
        WebElement userElement = driver.findElement(By.id("identifierId"));
        userElement.sendKeys(properties.getProperty("username"));

        driver.findElement(By.id("identifierNext")).click();

        Thread.sleep(5000);

        WebElement passwordElement = driver.findElement(By.name("password"));
        passwordElement.sendKeys(properties.getProperty("password"));
        driver.findElement(By.id("passwordNext")).click();

        Thread.sleep(5000);
    
        
        driver.findElement(By.cssSelector("div[class='T-I J-J5-Ji T-I-" + "KE L3']")).click();
        Thread.sleep(500);
        driver.findElement(By.xpath("//div[@class='T-I J-J5-Ji T-I-KE L3 T-I-JW T-I-JO']")).click();
       
        Thread.sleep(1000);
        
        driver.findElement(By.xpath("//textarea[@name='to']")).sendKeys("bubaimohanty@gmail.com");
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@name='subjectbox']")).sendKeys("Selenium script");
		driver.findElement(By.xpath("//div[@class='Am Al editable LW-avf']")).sendKeys("Selenium script to send mail");

        
        // emailSubject and emailbody to be used in this unit test.
        String emailSubject = properties.getProperty("email.subject");
        String emailBody = properties.getProperty("email.body"); 
        driver.findElement(By.xpath("//a[@class='J-Ke n0 uA']"));
        driver.findElement(By.xpath("//div[@id=':bi']"));
        driver.findElement(By.xpath("//div[@id=':c0']//div[@class='asa']"));
        driver.findElement(By.xpath("//div[@id=':k4']//div[@class='J-LC-Jo J-J5-Ji']"));
        driver.findElement(By.xpath("//div[contains(text(),'Apply')]"));
        
        
        
    }
}
